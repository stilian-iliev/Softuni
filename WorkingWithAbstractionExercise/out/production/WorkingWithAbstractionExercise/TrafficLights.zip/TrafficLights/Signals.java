package TrafficLights;

public enum Signals {
    RED,
    GREEN,
    YELLOW;
}
