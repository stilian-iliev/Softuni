package com.example.spotifyplaylistapp.models.enums;

public enum StyleEnum {
    POP, ROCK, JAZZ
}
