package say_hello_extend;

public interface Person {
    String getName();
    String sayHello();
}
