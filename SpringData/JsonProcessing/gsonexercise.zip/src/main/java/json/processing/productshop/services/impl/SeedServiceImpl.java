package json.processing.productshop.services.impl;

import com.google.gson.Gson;
import json.processing.productshop.entities.category.Category;
import json.processing.productshop.entities.product.Product;
import json.processing.productshop.entities.user.User;
import json.processing.productshop.repositories.CategoryRepository;
import json.processing.productshop.repositories.ProductRepository;
import json.processing.productshop.repositories.UserRepository;
import json.processing.productshop.services.SeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

@Service
public class SeedServiceImpl implements SeedService {
    private final Gson gson;
    private final String USERS_JSON_PATH = "src\\main\\resources\\files\\users.json";
    private final String PRODUCTS_JSON_PATH = "src\\main\\resources\\files\\products.json";
    private final String CATEGORIES_JSON_PATH = "src\\main\\resources\\files\\categories.json";

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    @Autowired
    public SeedServiceImpl(UserRepository userRepository, ProductRepository productRepository, CategoryRepository categoryRepository) {
        this.userRepository = userRepository;
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
        this.gson = new Gson();
    }

    @Override
    public void seedUsers() throws FileNotFoundException {
        User[] users = gson.fromJson(new FileReader(USERS_JSON_PATH), User[].class);
        userRepository.saveAll(Arrays.asList(users));
    }

    @Override
    public void seedProducts() throws FileNotFoundException {


        Product[] products = gson.fromJson(new FileReader(PRODUCTS_JSON_PATH), Product[].class);
        Arrays.asList(products).forEach(p -> {
            User seller = userRepository.findById(new Random().nextInt((int)userRepository.count())+1).get();
            int id = (new Random().nextInt((int) userRepository.count()*2));
            User buyer = userRepository.findById(id).orElse(null);
            Set<Category> categories = getRandomCategories();
            p.setSeller(seller);
            p.setBuyer(buyer);
            p.setCategories(categories);
        });

        productRepository.saveAll(Arrays.asList(products));

    }

    private Set<Category> getRandomCategories() {
        int size = new Random().nextInt((int) categoryRepository.count()+1);
        Set<Integer> ids = new HashSet<>();
        for (int i = 0; i < size; i++) {
            ids.add(new Random().nextInt((int) categoryRepository.count())+1);
        }
        return new HashSet<>(categoryRepository.findAllById(ids));
    }

    @Override
    public void seedCategories() throws FileNotFoundException {
        Category[] categories = gson.fromJson(new FileReader(CATEGORIES_JSON_PATH), Category[].class);
        categoryRepository.saveAll(Arrays.asList(categories));
    }
}
