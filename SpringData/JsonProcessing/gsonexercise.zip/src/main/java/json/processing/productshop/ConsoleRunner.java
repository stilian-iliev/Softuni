package json.processing.productshop;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.processing.productshop.repositories.CategoryRepository;
import json.processing.productshop.services.ProductService;
import json.processing.productshop.services.SeedService;
import json.processing.productshop.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ConsoleRunner implements CommandLineRunner {
    private final SeedService seedService;
    private final ProductService productService;
    private final UserService userService;
    private final CategoryRepository categoryRepository;

    private Gson gson;

    @Autowired
    public ConsoleRunner(SeedService seedService, ProductService productService, UserService userService, CategoryRepository categoryRepository) {
        this.seedService = seedService;
        this.productService = productService;
        this.userService = userService;
        this.categoryRepository = categoryRepository;
        gson = new GsonBuilder().setPrettyPrinting().create();
    }

    @Override
    public void run(String... args) throws Exception {
//        seedService.seedAll();

//        1
//        System.out.println(productService.findSellableDtoJsonByPriceBetween(BigDecimal.valueOf(500), BigDecimal.valueOf(1000)));

//        2
//        System.out.println(gson.toJson(userService.findAllUsersWithSoldProducts()));

//        3
//        System.out.println(gson.toJson(categoryRepository.findAllCategoryStatistics()));

//        4
//        System.out.println(gson.toJson(userService.findUsersSoldProductsSummary()));

    }
}
