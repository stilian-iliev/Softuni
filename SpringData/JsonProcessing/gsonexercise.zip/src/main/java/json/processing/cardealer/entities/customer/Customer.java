package json.processing.cardealer.entities.customer;

import json.processing.cardealer.entities.Sale;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;

    @Column(name = "date_of_birth")
    private LocalDateTime birthDate;

    @Column(name = "young_driver")
    private boolean isYoungDriver;

    @OneToMany(mappedBy = "customer")
    private Set<Sale> boughtCars;

    public Customer() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDateTime birthDate) {
        this.birthDate = birthDate;
    }

    public boolean isYoungDriver() {
        return isYoungDriver;
    }

    public void setYoungDriver(boolean youngDriver) {
        isYoungDriver = youngDriver;
    }

    public Set<Sale> getBoughtCars() {
        return boughtCars;
    }

    public void setBoughtCars(Set<Sale> boughtCars) {
        this.boughtCars = boughtCars;
    }
}
