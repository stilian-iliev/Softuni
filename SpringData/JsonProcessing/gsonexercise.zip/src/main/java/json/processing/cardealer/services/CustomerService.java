package json.processing.cardealer.services;

import json.processing.cardealer.entities.customer.SimpleCustomerDto;

import java.util.List;

public interface CustomerService {
    List<SimpleCustomerDto> findAllOrderedByBirthDay();
}
