package json.processing.cardealer.repositories;

import json.processing.cardealer.entities.PartSupplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PartSupplierRepository extends JpaRepository<PartSupplier, Integer> {
}
