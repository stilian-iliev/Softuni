package json.processing.cardealer.entities;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "part_suppliers")
public class PartSupplier {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;

    @Column(name = "uses_imported_parts")
    private boolean usesImportedParts;

    @OneToMany(mappedBy = "supplier")
    private List<Part> parts;

    public PartSupplier() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isUsesImportedParts() {
        return usesImportedParts;
    }

    public void setUsesImportedParts(boolean usesImportedParts) {
        this.usesImportedParts = usesImportedParts;
    }

    public List<Part> getParts() {
        return parts;
    }

    public void setParts(List<Part> parts) {
        this.parts = parts;
    }
}
