package json.processing.cardealer.services.impl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import json.processing.cardealer.entities.*;
import json.processing.cardealer.entities.customer.Customer;
import json.processing.cardealer.repositories.*;
import json.processing.cardealer.services.DealerSeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

@Service
public class DealerSeedServiceImpl implements DealerSeedService {
    private final Gson gson;

    private final CarRepository carRepository;
    private final CustomerRepository customerRepository;
    private final PartRepository partRepository;
    private final PartSupplierRepository partSupplierRepository;
    private final SaleRepository saleRepository;

    private final String FILES_PATH = "src\\main\\resources\\files\\";

    @Autowired
    public DealerSeedServiceImpl(CarRepository carRepository, CustomerRepository customerRepository, PartRepository partRepository, PartSupplierRepository partSupplierRepository, SaleRepository saleRepository) {
        this.carRepository = carRepository;
        this.customerRepository = customerRepository;
        this.partRepository = partRepository;
        this.partSupplierRepository = partSupplierRepository;
        this.saleRepository = saleRepository;

        gson = new GsonBuilder().setPrettyPrinting().create();
    }


    @Override
    public void seedSuppliers() throws FileNotFoundException {
        PartSupplier[] suppliers = gson.fromJson(new FileReader(FILES_PATH + "suppliers.json"), PartSupplier[].class);
        partSupplierRepository.saveAll(Arrays.asList(suppliers));
    }

    @Override
    public void seedParts() throws FileNotFoundException {
        Part[] parts = gson.fromJson(new FileReader(FILES_PATH + "parts.json"), Part[].class);
        Arrays.stream(parts).forEach(p -> {
            PartSupplier supplier = partSupplierRepository.getById(new Random().nextInt((int) partSupplierRepository.count())+1);
            p.setSupplier(supplier);
        });
        partRepository.saveAll(Arrays.asList(parts));
    }

    @Override
    @Transactional
    public void seedCars() throws FileNotFoundException {
        Car[] cars = gson.fromJson(new FileReader(FILES_PATH + "cars.json"), Car[].class);
        Arrays.stream(cars).forEach(c ->{
            int size = new Random().nextInt(2)+4;
            Set<Part> parts = new HashSet<>();
            for (int i = 0; i < size; i++) {
                Part part = partRepository.getById(new Random().nextInt((int) partRepository.count())+1);
                parts.add(part);
            }
            c.setParts(parts);
        });
        carRepository.saveAll(Arrays.asList(cars));
    }

    @Override
    public void seedCustomers() throws FileNotFoundException {
        Customer[] customers = gson.fromJson(new FileReader(FILES_PATH + "customers.json"), Customer[].class);
        customerRepository.saveAll(Arrays.asList(customers));
    }

    @Override
    public void seedSales() throws FileNotFoundException {
        double[] discounts = new double[]{0, 5, 10, 15, 20, 30, 40, 50};

        for (int i = 0; i <10; i++) {
            double discount = discounts[new Random().nextInt(discounts.length)];
            Car car = carRepository.getById(new Random().nextInt((int) carRepository.count())+1);
            Customer customer = customerRepository.getById(new Random().nextInt((int) customerRepository.count())+1);
            Sale sale = new Sale(car, customer, discount);
            saleRepository.save(sale);
        }
    }


}
