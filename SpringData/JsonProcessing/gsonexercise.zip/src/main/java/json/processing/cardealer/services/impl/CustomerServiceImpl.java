package json.processing.cardealer.services.impl;

import json.processing.cardealer.entities.customer.SimpleCustomerDto;
import json.processing.cardealer.repositories.CustomerRepository;
import json.processing.cardealer.services.CustomerService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {
    private final CustomerRepository customerRepository;

    private ModelMapper mapper;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;

        mapper = new ModelMapper();
    }

    @Override
    public List<SimpleCustomerDto> findAllOrderedByBirthDay() {

        return customerRepository.findAllOrderByBirthDateAscIsYoungDriverAsc().stream().map(e -> mapper.map(e, SimpleCustomerDto.class)).collect(Collectors.toList());
    }
}
