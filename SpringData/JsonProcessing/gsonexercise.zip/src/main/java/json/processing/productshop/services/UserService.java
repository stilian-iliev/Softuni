package json.processing.productshop.services;

import json.processing.productshop.entities.user.UserWithSoldProductsDto;
import json.processing.productshop.entities.user.UsersProductsSummary;

import java.util.List;

public interface UserService {
    List<UserWithSoldProductsDto> findAllUsersWithSoldProducts();

    UsersProductsSummary findUsersSoldProductsSummary();
}
