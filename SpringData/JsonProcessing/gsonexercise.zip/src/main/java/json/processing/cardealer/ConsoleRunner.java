package json.processing.cardealer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import json.processing.cardealer.services.CustomerService;
import json.processing.cardealer.services.DealerSeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class ConsoleRunner implements CommandLineRunner {
    private final DealerSeedService dealerSeedService;
    private final CustomerService customerService;

    private final Gson gson;

    @Autowired
    public ConsoleRunner(DealerSeedService dealerSeedService, CustomerService customerService) {
        this.dealerSeedService = dealerSeedService;
        this.customerService = customerService;
        gson = new GsonBuilder().setPrettyPrinting().create();
    }

    @Override
    public void run(String... args) throws Exception {
//        System.out.println(gson.toJson(customerService.findAllOrderedByBirthDay()));

        dealerSeedService.seedCustomers();
    }
}
