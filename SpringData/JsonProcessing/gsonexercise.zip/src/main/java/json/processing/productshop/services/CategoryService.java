package json.processing.productshop.services;

import json.processing.productshop.entities.category.CategoryStatisticsDto;

import java.util.List;

public interface CategoryService {
    List<CategoryStatisticsDto> findCategoriesStatistics();
}
