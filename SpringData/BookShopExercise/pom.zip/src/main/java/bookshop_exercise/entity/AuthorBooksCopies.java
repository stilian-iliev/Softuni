package bookshop_exercise.entity;

public interface AuthorBooksCopies {
    String getFullName();
    long getBooksCopies();
}
