package bookshop_exercise.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
