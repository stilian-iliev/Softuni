package bookshop_exercise.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
