package xml.services;


import xml.entities.category.CategoriesListDto;

public interface CategoryService {

    CategoriesListDto findCategoryStatistics();
}
