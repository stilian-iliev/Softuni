package GenericBox;

public class Box {
    public static<T> String toString(T input){
        String clazz = input.getClass().toString().substring(6);
        return String.format("%s: %s",clazz,input);
    }
}
