package GenericBox;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        List<String> strings = new ArrayList<>();

        int n = Integer.parseInt(sc.nextLine());
        while (n-- > 0) {
            strings.add(Box.toString(Integer.parseInt(sc.nextLine())));
        }
        int[] indexes = Arrays.stream(sc.nextLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();

        String temp = strings.get(indexes[0]);
        strings.set(indexes[0],strings.get(indexes[1]));
        strings.set(indexes[1], temp);

        strings.forEach(System.out::println);
    }
}
