package GenericBox;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        List<Double> strings = new ArrayList<>();

        int n = Integer.parseInt(sc.nextLine());
        while (n-- > 0) {
            strings.add(Double.parseDouble(sc.nextLine()));
        }
        double value = Double.parseDouble(sc.nextLine());

        System.out.println(Box.compare(strings, value));
    }
}
