package GenericBox;

import java.util.List;

public class Box {
    public static<T> String toString(T input){
        String clazz = input.getClass().toString().substring(6);
        return String.format("%s: %s",clazz,input);
    }
    public static <T extends Comparable<T>> int compare(List<T> list, T value){
        return (int) list.stream().filter(e-> e.compareTo(value)>0).count();
    }
}
