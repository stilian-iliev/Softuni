package StackIterator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Stack<Integer> stack = new Stack<>();

        String input = sc.nextLine();
        while (!input.equals("END")){
            if (input.equals("Pop")){
                stack.pop();
            } else {
                push(input,stack);
            }
            input = sc.nextLine();
        }
        stack.forEach(System.out::println);
        stack.forEach(System.out::println);
    }
    private static void push(String input, Stack<Integer> stack){
        input = input.substring(5).replace(",","");
        List<Integer> numbers = Arrays.stream(input.split("\\s+")).map(Integer::parseInt).collect(Collectors.toList());
        numbers.forEach(stack::push);
    }
}
