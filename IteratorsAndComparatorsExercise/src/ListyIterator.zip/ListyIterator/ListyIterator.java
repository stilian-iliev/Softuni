package ListyIterator;

import java.util.List;

public class ListyIterator {
    private List<String> list;
    private int currentIndex;

    public void create(List<String> list) {
        this.list = list;
        currentIndex = 0;
    }

    public boolean next() {
        if (hasNext()) {
            currentIndex++;
            return true;
        } else return false;
    }

    public boolean hasNext() {
        return (currentIndex + 1) < list.size();
    }

    public void print(){
        if (list.isEmpty()){
            System.out.println("Invalid Operation!");
        } else {
            System.out.println(list.get(currentIndex));
        }
    }
}
