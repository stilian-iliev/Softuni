package ReusingClasses;

public class Main {
    public static void main(String[] args) {
        RandomArrayList<String> ral = new RandomArrayList<>();

        ral.add("asdf");
        ral.add("fdsa");

        System.out.println(ral.getRandomElement());
    }
}
