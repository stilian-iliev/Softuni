package ListUtilities;

import java.util.Collections;
import java.util.List;

public class ListUtils<T extends Comparable<T>> {

    public T getMin(List<T> input){
        error(input);
        return Collections.min(input);
    }
    public T getMax(List<T> input){
        error(input);
        return Collections.max(input);
    }
    private void error(List<T> list){
        if (list.isEmpty()) throw new IllegalArgumentException();
    }
}
