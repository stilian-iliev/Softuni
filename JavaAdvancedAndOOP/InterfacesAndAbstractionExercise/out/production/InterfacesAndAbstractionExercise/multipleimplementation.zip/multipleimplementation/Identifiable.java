package multipleimplementation;

public interface Identifiable {
    String getId();
}
