package defineanintefaceperson;

public interface Person {
    String getName();
    int getAge();
}
