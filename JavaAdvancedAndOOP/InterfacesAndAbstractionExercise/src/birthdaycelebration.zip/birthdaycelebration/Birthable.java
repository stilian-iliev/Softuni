package birthdaycelebration;

public interface Birthable {
    String getBirthDate();
}
