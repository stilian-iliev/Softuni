package birthdaycelebration;

public interface Person {
    String getName();
    int getAge();
}
