package birthdaycelebration;

public interface Identifiable {
    String getId();
}
