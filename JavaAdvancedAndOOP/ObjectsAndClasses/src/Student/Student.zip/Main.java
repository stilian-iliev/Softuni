package Student;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Student> students = new ArrayList<Student>();
        String[] input = sc.nextLine().split(" ");
        while (!input[0].equals("end")){
            Student student = new Student(input[0],input[1],Integer.parseInt(input[2]),input[3]);
            students.add(student);
            input = sc.nextLine().split(" ");
        }
        String town = sc.nextLine();
        for (Student student : students) {
            if (town.equals(student.getHomeTown())){
                System.out.printf("%s %s is %d years old%n", student.getFirstName(),student.getLastName(), student.getAge());
            }
        }
    }
}
