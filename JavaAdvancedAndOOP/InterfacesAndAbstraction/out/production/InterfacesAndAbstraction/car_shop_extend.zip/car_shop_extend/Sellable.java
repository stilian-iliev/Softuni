package car_shop_extend;

public interface Sellable {
    Double getPrice();
}
