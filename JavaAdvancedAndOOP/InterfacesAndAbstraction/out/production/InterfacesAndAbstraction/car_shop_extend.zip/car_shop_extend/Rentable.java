package car_shop_extend;

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();
}
